# * Project1_Beom_Czech_Hwang

## * Group:

💻Jun Beom(Project, Select, Makefile),
💻Brandon Czech(Union, Minus),
💻 Wonjoon Hwang(Join, Doc)

## * How to Compile, Run, Clean:

### Before running the code,

cd project1_Beom_Czech_Hwang

Make sure that you are in the right directory.

### Compile all Java files in the source directory

: make cl

### Run the application

: make run

### Clean up compiled files and temporary files

: make clean
